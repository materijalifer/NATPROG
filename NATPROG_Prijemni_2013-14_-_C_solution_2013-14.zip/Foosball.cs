﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace Foosball
{
    class Program
    {
        static void Main(string[] args)
        {
            List<DateTime> datetime = new List<DateTime>();
            String pom;

            while ((pom = Console.ReadLine()) != null)
            {
                datetime.Add(DateTime.Parse(pom));
            }

            Display(SortAscending(datetime));

            Console.ReadLine();
        }

        static List<DateTime> SortAscending(List<DateTime> list)
        {
            list.Sort((a, b) => a.CompareTo(b));
            return list;
        }

        static void Display(List<DateTime> list)
        {
            foreach (var datetime in list)
            {
                //dd.mm.yyy hh:mm:ss
                Console.WriteLine(datetime.ToString("dd.MM.yyyy. HH:mm:ss", CultureInfo.InvariantCulture));
            }
        }
    }
}
