﻿using System;
using System.Linq;

namespace Staza
{
    public class Prijatelj
    {
        public static Int32 BrojCiklusa = 0;

        public String Name;
        public Int32 Pozicija;
        public Int32 Brzina;

        public Prijatelj(String Name)
        {
            this.Name = Name;
        }

        public override string ToString()
        {
            return this.Name + " " + Pozicija.ToString() + " " + Brzina.ToString();
        }

        public Prijatelj OdvoziCiklus(Int32 DuljinaStaze)
        {
            if (DuljinaStaze >= (this.Pozicija + this.Brzina))
                this.Pozicija += this.Brzina;
            else
            {
                this.Pozicija = this.Brzina - (DuljinaStaze - this.Pozicija);
            }
            return this;
        }

    }

    public static class PrijateljExtensions
    {
        public static String IzračunajSusret(this Prijatelj Tomislav, Prijatelj Matija, Int32 Duljina)
        {
            if (Math.Abs(Tomislav.Brzina - Matija.Brzina) == Duljina)
                return "INF";
            else if (Tomislav.Brzina == 0 && Matija.Brzina == 0)
            {
                return "0";
            }
            else
            {
                do
                {
                    Prijatelj.BrojCiklusa++;
                } while (Tomislav.OdvoziCiklus(Duljina).Pozicija != Matija.OdvoziCiklus(Duljina).Pozicija);

                return Prijatelj.BrojCiklusa.ToString();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Int32 DuljinaStaze = Convert.ToInt32(Console.ReadLine());
            Prijatelj Tomislav = new Prijatelj("Tomislav");
            Prijatelj Matija = new Prijatelj("Matija");

            String pom = Console.ReadLine();
            Tomislav.Pozicija = Convert.ToInt32(pom.Split(' ').First());
            Matija.Pozicija = Convert.ToInt32(pom.Split(' ').Last());

            pom = Console.ReadLine();
            Tomislav.Brzina = Convert.ToInt32(pom.Split(' ').First());
            Matija.Brzina = Convert.ToInt32(pom.Split(' ').Last());

            Console.WriteLine(Tomislav.IzračunajSusret(Matija, DuljinaStaze));
        }
    }
}
